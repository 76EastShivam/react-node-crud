//import logo from './logo.svg';
import './App.css';
import Homepage from './components/homepage/homepage';
import Signup from './components/signup/signup';
import Login from './components/login/login';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom"

function App() {
  return (
    <div className="App">
      {/* <Router>
        <Routes>
          <Route exact path='/'><Homepage /></Route>
          <Route path='/login'><Login /></Route>
          <Route path='/signup'><Signup /></Route>
          </Routes> 
      </Router> */}
      {/* <Homepage />
      <Login />
      <Signup /> */}
      <Router>
        <Routes>
          {/* <Route  path="/" element={<Homepage />} > */}
            <Route path='/login' element={<Login />} />
            <Route path='/signup' element={<Signup />} />
            <Route path='/*' element={<Homepage to="/homepage"/>}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
