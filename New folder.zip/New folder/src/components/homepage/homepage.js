import React from "react"
import "./homepage.css"
import { useNavigate } from 'react-router-dom';



const Homepage = () => {


    const navigate = new useNavigate();

    const navigateHome = () => {
        // 👇️ navigate to /
        navigate('/login');
    };



    return (
        <div className="homepage">
            <h1>hello homepage</h1>
            <div className="button" onClick={navigateHome} >Logout</div>
        </div>
    )

}
export default Homepage